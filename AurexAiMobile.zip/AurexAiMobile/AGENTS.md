# AGENTS.md — AUREX AI Mobile

## Co to jest ten projekt
Kompletny kod źródłowy natywnej aplikacji Android (Kotlin + Jetpack Compose) — osobisty asystent AI z diagnostyką urządzenia, automatyzacją, analityką, pamięcią, powiadomieniami i centrum bezpieczeństwa.

## Jak otworzyć i zbudować
1. Otwórz folder `AurexAiMobile` w Android Studio (File → Open).
2. `File → Sync Project with Gradle Files`.
3. `Build → Make Project` lub `Run → Run 'app'` na emulatorze/urządzeniu z Androidem (minSdk 24, targetSdk 34).
4. Uprawnienia niebezpieczne (mikrofon, pliki, powiadomienia) przyznaj ręcznie w Ustawieniach systemu.

## Jak uruchomić testy
- Testy jednostkowe: `./gradlew test` (w Android Studio lub terminalu z Android SDK).
- W tym piaskownicy nie ma Android SDK, więc kompilacja APK nie jest możliwa lokalnie.

## Kluczowe pliki
- `app/build.gradle` — zależności (Compose, Room, WorkManager, Navigation)
- `app/src/main/AndroidManifest.xml` — deklaracje uprawnień i usług
- `app/src/main/java/com/aurex/ai/MainActivity.kt` + `AppNavigation()` — 11 zakładek nawigacji
- `app/src/main/java/com/aurex/ai/data/` — Room (encje, DAO, baza)
- `app/src/main/java/com/aurex/ai/ui/` — ekrany i ViewModel-e (czat, głos, skaner, manager, automatyzacja, analityka, pamięć, powiadomienia, bezpieczeństwo, ustawienia)
- `app/src/main/java/com/aurex/ai/network/ApiClient.kt` — klient backendu (bez klucza API w aplikacji)
- `app/src/main/java/com/aurex/ai/services/` — Foreground Service, BootReceiver

## Zasady (z wymagań użytkownika)
- Nie tworzyć atrap/fikcyjnych danych tam, gdzie wymagane są rzeczywiste pomiary (skaner urządzenia używa Android API).
- Każdy przycisk wykonuje prawdziwą funkcję.
- Nie obchodzić zabezpieczeń Androida, nie ukrywać mikrofonu, nie instalować aplikacji bez wiedzy użytkownika.
- Nie umieszczać sekretów/kluczy API w kodzie aplikacji (OpenAI przez backend).

## Ograniczenia (Android)
- Działanie w tle ograniczane przez system (battery optimization, doze mode).
- Uprawnienie RECORD_AUDIO wymaga przyznania przez użytkownika w runtime.
- Nie ma gwarancji ciągłej pracy 24/7 — usługi mogą być zatrzymane przez producenta.