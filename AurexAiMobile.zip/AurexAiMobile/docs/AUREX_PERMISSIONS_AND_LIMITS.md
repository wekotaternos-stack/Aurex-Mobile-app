# AUREX AI — Uprawnienia, ograniczenia, konfiguracja i koszty API

## Uprawnienia wymagane przez aplikację (w AndroidManifest.xml)

| Uprawnienie | Do czego służy | Kiedy przyznać |
|---|---|---|
| RECORD_AUDIO | Nagrywanie głosu w asystencie | Przy pierwszym użyciu mikrofonu |
| MODIFY_AUDIO_SETTINGS | Sterowanie dźwiękiem | Przy użyciu głosu |
| INTERNET / ACCESS_NETWORK_STATE | Połączenie z backendem | Przy uruchomieniu |
| BATTERY_STATS | Odczyt stanu baterii (skaner) | Przy skanowaniu |
| QUERY_ALL_PACKAGES | Lista zainstalowanych aplikacji (manager) | Przy otwarciu managera |
| REQUEST_INSTALL_PACKAGES | Pomoc przy instalacji aplikacji | Przy instalacji |
| POST_NOTIFICATIONS | Powiadomienia asystenta/diagnostyka | Przy pierwszym powiadomieniu |
| FOREGROUND_SERVICE | Działanie usługi głosowej w tle | Przy włączeniu Wake 24/7 |
| RECEIVE_BOOT_COMPLETED | Wznawianie zadań po restarcie | Przy instalacji |
| READ_EXTERNAL_STORAGE / READ_MEDIA_* | Przegląd plików (manager) | Przy dostępie do plików |

## Co ogranicza Android (nie można tego obejść)
- **Działanie w tle:** system może zatrzymać usługi w trybie doze/battery optimization. Nie ma gwarancji ciągłej pracy 24/7.
- **Mikrofon:** dostęp tylko po przyznaniu uprawnienia przez użytkownika w runtime; aplikacja nie może podsłuchiwać w tle bez wiedzy użytkownika.
- **Uprawnienia niebezpieczne:** wszystkie wymagają ręcznej zgody użytkownika w Ustawieniach.
- **Instalacja aplikacji:** tylko przez oficjalne mechanizmy (Pakiet Installer), z wiedzą użytkownika.
- **Brak ukrytego monitorowania:** aplikacja nie przechwytuje danych innych aplikacji ani nie podsłuchuje bez zgody.

## Co wymaga konfiguracji zewnętrznej
- **Backend AI:** OpenAI (lub inny) przez bezpieczny backend — klucz API przechowywany wyłącznie po stronie serwera, nigdy w aplikacji.
- **Powiadomienia:** kanały powiadomień tworzone w kodzie (NotificationManager).
- **WorkManager:** zadania okresowe (automatyczne raporty diagnostyczne).

## Koszty API (szacunkowe, OpenAI)
- Rozmowa tekstowa: zależna od liczby tokenów (model GPT-3.5/4-turbo itp.).
- Rozpoznawanie mowy (STT) i synteza mowy (TTS): dodatkowe koszty za minutę/znak.
- Analiza zdjęć/dokumentów: koszt za przetworzony obraz.
- Szacunek miesięczny zależy od intensywności użytkowania — ustaw limity wydatków w panelu dostawcy API.

## Co działa offline
- Interfejs użytkownika, nawigacja, przegląd zapisanej lokalnie pamięci, historia powiadomień, ustawienia.
- Część diagnostyki urządzenia (odczyt baterii, RAM, dysku, aplikacji) nie wymaga internetu.

## Co wymaga internetu
- Rozmowa z AI (backend), wysyłanie raportów, eksport do zewnętrznych serwisów, aktualizacje aplikacji.

## Bezpieczeństwo danych
- Dane lokalne przechowywane w bazie Room (można zaszyfrować — EncryptedSharedPreferences).
- Brak kluczy API w kodzie aplikacji.
- Przycisk STOP ALL zatrzymuje zadania i usługi AUREX.
- Opcja wyczyszczenia wszystkich danych w Centrum Bezpieczeństwa.