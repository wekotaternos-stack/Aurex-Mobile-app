package com.aurex.ai.ui.voice

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class VoiceWakeViewModel : ViewModel() {

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _micActive = MutableStateFlow(false)
    val micActive: StateFlow<Boolean> = _micActive.asStateFlow()

    private val _continuousMode = MutableStateFlow(false)
    val continuousMode: StateFlow<Boolean> = _continuousMode.asStateFlow()

    private val _wakeWordEnabled = MutableStateFlow(false)
    val wakeWordEnabled: StateFlow<Boolean> = _wakeWordEnabled.asStateFlow()

    private val _status = MutableStateFlow("Mikrofon wyłączony")
    val status: StateFlow<String> = _status.asStateFlow()

    fun toggleListening() {
        if (_isListening.value) stopListening() else startListening()
    }

    private fun startListening() {
        // Wymaga uprawnienia RECORD_AUDIO przyznanego przez użytkownika w runtime.
        _isListening.value = true
        _micActive.value = true
        _status.value = "Słucham…"
    }

    private fun stopListening() {
        _isListening.value = false
        _micActive.value = false
        _status.value = "Mikrofon wyłączony"
    }

    fun interrupt() {
        _micActive.value = false
        _status.value = "Przerwano wypowiedź"
    }

    fun toggleContinuous() {
        _continuousMode.value = !_continuousMode.value
        _status.value = if (_continuousMode.value) "Tryb ciągły włączony" else "Tryb ciągły wyłączony"
    }

    fun toggleWakeWord() {
        _wakeWordEnabled.value = !_wakeWordEnabled.value
        _status.value = if (_wakeWordEnabled.value) "Wake 24/7 włączony" else "Wake 24/7 wyłączony"
    }
}
