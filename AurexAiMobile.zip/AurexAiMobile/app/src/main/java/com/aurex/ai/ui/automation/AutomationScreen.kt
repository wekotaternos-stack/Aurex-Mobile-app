package com.aurex.ai.ui.automation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun AutomationScreen(viewModel: AutomationViewModel = AutomationViewModel()) {
    val tasks by viewModel.tasks.collectAsState()
    val history by viewModel.history.collectAsState()
    val error by viewModel.error.collectAsState()
    var newTitle by remember { mutableStateOf("") }
    var newType by remember { mutableStateOf("harmonogram") }
    var newSchedule by remember { mutableStateOf("codziennie") }
    var showAdd by remember { mutableStateOf(false) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Automatyzacja") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(imageVector = androidx.compose.material.Icons.Default.Add, contentDescription = "Dodaj zadanie")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            error?.let {
                Text(text = it, color = Color(0xFFEF4444), modifier = Modifier.padding(horizontal = 16.dp, top = 4.dp))
            }
            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = tasks, key = { it.id }) { task ->
                    TaskRow(task = task, onToggle = { viewModel.toggleTask(task.id) }, onDelete = { viewModel.deleteTask(task.id) }, onRun = { viewModel.markRun(task.id, task.title, "ukonczone") })
                }
            }
            if (tasks.isEmpty()) {
                Text(text = "Brak zadań automatyzacji. Dodaj pierwsze zadanie.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C), modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 24.dp))
            }
            Divider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            Text(text = "Historia wykonania", style = MaterialTheme.typography.titleMedium, color = Color(0xFFEAEAF2), modifier = Modifier.padding(horizontal = 16.dp))
            LazyColumn(
                modifier = Modifier.padding(horizontal = 16.dp).heightIn(min = 140.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(items = history.reversed(), key = { it.taskId + it.executedAt }) { entry ->
                    HistoryRow(entry = entry)
                }
            }
        }
    }

    if (showAdd) {
        AddTaskDialog(
            onDismiss = { showAdd = false },
            onConfirm = { title, type, schedule ->
                if (title.isNotBlank()) {
                    viewModel.addTask(title, type, schedule)
                    showAdd = false
                }
            },
            title = newTitle,
            type = newType,
            schedule = newSchedule,
            onTitleChange = { newTitle = it },
            onTypeChange = { newType = it },
            onScheduleChange = { newSchedule = it }
        )
    }
}

@Composable
private fun TaskRow(
    task: AutomationTask,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    onRun: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = androidx.compose.foundation.layout.Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
            Text(text = task.title, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
            Text(text = "${task.type} • ${task.schedule}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF))
            task.lastRun?.let {
                Text(text = "Ostatnie uruchomienie: ${java.time.Instant.ofEpochMilli(it).toString()}", style = MaterialTheme.typography.captionSmall, color = Color(0xFF4B4B5C))
            }
        }
        Switch(checked = task.enabled, onCheckedChange = { onToggle() })
        IconButton(onClick = onRun) { Icon(imageVector = androidx.compose.material.Icons.Default.PlayCircle, contentDescription = "Uruchom") }
        IconButton(onClick = onDelete) { Icon(imageVector = androidx.compose.material.Icons.Default.Delete, contentDescription = "Usuń") }
    }
}

@Composable
private fun HistoryRow(entry: AutomationHistoryEntry) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = androidx.compose.foundation.layout.Alignment.CenterVertically
    ) {
        Text(text = entry.taskTitle, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = entry.status, style = MaterialTheme.typography.bodySmall, color = if (entry.status == "ukonczone") Color(0xFF10B981) else Color(0xFFEF4444))
        Spacer(modifier = Modifier.weight(1f))
        Text(text = java.time.Instant.ofEpochMilli(entry.executedAt).toString().substring(0, 16), style = MaterialTheme.typography.captionSmall, color = Color(0xFF4B4B5C))
    }
}

@Composable
private fun AddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit,
    title: String,
    type: String,
    schedule: String,
    onTitleChange: (String) -> Unit,
    onTypeChange: (String) -> Unit,
    onScheduleChange: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Dodaj zadanie") },
        text = {
            Column(modifier = Modifier.width(280.dp)) {
                TextField(value = title, onValueChange = onTitleChange, label = { Text("Nazwa zadania") })
                Spacer(modifier = Modifier.height(8.dp))
                TextField(value = type, onValueChange = onTypeChange, label = { Text("Typ (harmonogram/przypomnienie/raport/reguła)") })
                Spacer(modifier = Modifier.height(8.dp))
                TextField(value = schedule, onValueChange = onScheduleChange, label = { Text("Harmonogram (np. codziennie 08:00)") })
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(title, type, schedule) }) { Text(text = "Dodaj") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(text = "Anuluj") }
        }
    )
}
