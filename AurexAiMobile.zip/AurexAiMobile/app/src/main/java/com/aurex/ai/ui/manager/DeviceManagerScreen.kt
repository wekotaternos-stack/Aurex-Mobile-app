package com.aurex.ai.ui.manager

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DeviceManagerScreen(viewModel: DeviceManagerViewModel = DeviceManagerViewModel(LocalContext.current)) {
    val apps by viewModel.apps.collectAsState()
    val error by viewModel.error.collectAsState()
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Manager urządzenia") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            error?.let {
                Text(text = it, color = Color(0xFFEF4444), modifier = Modifier.padding(horizontal = 16.dp, top = 4.dp))
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .horizontalArrangement(androidx.compose.foundation.layout.Arrangement.SpaceBetween)
            ) {
                Button(onClick = { scope.launch { viewModel.loadApps() } }) {
                    Text("Odśwież listę")
                }
                Button(onClick = { viewModel.openSystemSettings() }) {
                    Text("Ustawienia systemu")
                }
            }
            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(items = apps, key = { it.packageName }) { app ->
                    AppRow(app = app, onOpen = { viewModel.openApp(app.packageName) }, onSettings = { viewModel.openAppSettings(app.packageName) })
                }
            }
            if (apps.isEmpty()) {
                Text(
                    text = "Brak aplikacji. Naciśnij 'Odśwież listę'.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF4B4B5C),
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 24.dp)
                )
            }
        }
    }
}

@Composable
private fun AppRow(
    app: ManagerAppItem,
    onOpen: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { onOpen() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        ImageBitmapPlaceholder(iconRes = app.iconRes)
        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(text = app.appName ?: app.packageName, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
            Text(text = app.packageName, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF))
            if (app.isSystem) {
                Text(text = "Systemowa", style = MaterialTheme.typography.captionSmall, color = Color(0xFF3B82F6))
            }
        }
        IconButton(onClick = onSettings) {
            Icon(imageVector = androidx.compose.material.Icons.Default.Settings, contentDescription = "Ustawienia aplikacji")
        }
    }
}

@Composable
private fun ImageBitmapPlaceholder(iconRes: Int) {
    Box(
        modifier = Modifier.size(40.dp),
        contentAlignment = Alignment.Center
    ) {
        // Placeholder dla ikony aplikacji (w pełnej wersji pobierana z PackageManager)
        Icon(
            imageVector = androidx.compose.material.Icons.Default.AppRegistration,
            contentDescription = null,
            tint = Color(0xFF8B5CF6),
            modifier = Modifier.size(24.dp)
        )
    }
}
