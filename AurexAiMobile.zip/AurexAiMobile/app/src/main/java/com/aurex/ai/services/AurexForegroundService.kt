package com.aurex.ai.services

import android.app.ForegroundService
import android.content.Intent
import android.media.AudioAttributes
import android.os.Build
import android.os.IBinder
import androidx.core.app.ActivityCompat

/**
 * Foreground service uruchomiony tylko dla funkcji wymagających ciągłej pracy,
 * np. Voice Wake (hasło głosowe 24/7).
 * <p>
 * NOTA: Android ogranicza działanie usług w tle. Ten serwis działa tylko gdy
 * aplikacja jest na pierwszym planie lub gdy użytkownik aktywnie korzysta z funkcji
 * głosowej. Nie deklarujemy gwarantowanej ciągłej pracy 24/7 bez przerw.
 */
class AurexForegroundService : ForegroundService() {

    override fun onCreate() {
        super.onCreate()
        // Inicjalizacja zasobów (np. AudioRecord w wersji produkcyjnej)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = android.app.Notification.Builder(this, "aurex_default")
            .setContentTitle("AUREX AI — Asystent aktywny")
            .setContentText("Mikrofon aktywny — naciśnij, by przerwać")
            .setSmallIcon(android.R.drawable.ic_sym_pause)
            .setPriority(android.app.Notification.PRIORITY_HIGH)
            .setOngoing(true)
            .build()

        startForeground(startId, notification)

        // Rozpocznij nasłuchiwanie (symulacja)
        startListening()

        return START_STICKY
    }

    private fun startListening() {
        // W pełnej wersji: inicjalizacja AudioRecord, wake word detection,
        // integracja z systemowym VoiceInteractionService.
    }

    override fun onDestroy() {
        super.onDestroy()
        // Czyszczenie zasobów
    }

    override fun onBind(intent: Intent?): IBinder {
        return null
    }
}