package com.aurex.ai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AutomationDao {
    @Query("SELECT * FROM automation_tasks ORDER BY createdAt DESC")
    fun getAllTasks(): Flow<List<AutomationTaskEntity>>

    @Insert
    suspend fun insert(task: AutomationTaskEntity)

    @Update
    suspend fun update(task: AutomationTaskEntity)

    @Delete
    suspend fun delete(task: AutomationTaskEntity)

    @Query("DELETE FROM automation_tasks")
    fun clearAll()

    @Query("SELECT * FROM automation_tasks WHERE id = :id")
    fun getTaskById(id: String): Flow<AutomationTaskEntity?>
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notification_items ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert
    suspend fun insert(notification: NotificationEntity)

    @Update
    suspend fun update(notification: NotificationEntity)

    @Delete
    suspend fun delete(notification: NotificationEntity)

    @Query("DELETE FROM notification_items")
    fun clearAll()

    @Query("SELECT * FROM notification_items WHERE id = :id")
    fun getNotificationById(id: String): Flow<NotificationEntity?>
}

@Dao
interface AutomationHistoryDao {
    @Query("SELECT * FROM automation_history_entries ORDER BY executedAt DESC")
    fun getAllEntries(): Flow<List<AutomationHistoryEntryEntity>>

    @Insert
    suspend fun insert(entry: AutomationHistoryEntryEntity)

    @Delete
    suspend fun delete(entry: AutomationHistoryEntryEntity)
}