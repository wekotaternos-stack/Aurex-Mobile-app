package com.aurex.ai.ui.settings

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.material3.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext

@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val context = LocalContext.current
    val backendUrl by viewModel.backendUrl.collectAsState()
    val model by viewModel.model.collectAsState()
    val offlineMode by viewModel.offlineMode.collectAsState()
    val voiceResponses by viewModel.voiceResponses.collectAsState()

    var backendUrlInput by remember { mutableStateOf(backendUrl) }
    var modelInput by remember { mutableStateOf(model) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = stringResource(id = R.string.settings_title)) },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            Text(text = stringResource(id = R.string.settings_backend_url), style = MaterialTheme.typography.labelMedium, color = Color(0xFF9CA3AF), modifier = Modifier.padding(horizontal = 16.dp, top = 24.dp, bottom = 4.dp))
            TextField(
                value = backendUrlInput,
                onValueChange = { backendUrlInput = it },
                label = { Text("np. https://api.twoj-backend.pl/v1") },
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                colors = TextFieldDefaults.colors(unfocusedContainerColor = Color(0xFF161622), focusedContainerColor = Color(0xFF1A1A28))
            }
            Button(onClick = { viewModel.setBackendUrl(backendUrlInput) }, modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                Text("Zapisz adres backendu")
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(text = stringResource(id = R.string.settings_model), style = MaterialTheme.typography.labelMedium, color = Color(0xFF9CA3AF), modifier = Modifier.padding(horizontal = 16.dp, top = 24.dp, bottom = 4.dp))
            TextField(
                value = modelInput,
                onValueChange = { modelInput = it },
                label = { Text("np. gpt-4o-mini, llama3, mistral") },
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                colors = TextFieldDefaults.colors(unfocusedContainerColor = Color(0xFF161622), focusedContainerColor = Color(0xFF1A1A28))
            }
            Button(onClick = { viewModel.setModel(modelInput) }, modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                Text("Zapisz model")
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(text = stringResource(id = R.string.settings_model), style = MaterialTheme.typography.titleMedium, color = Color(0xFFEAEAF2), modifier = Modifier.padding(horizontal = 16.dp, top = 8.dp, bottom = 4.dp))

            Card(modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A28))) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(id = R.string.settings_offline_mode), style = MaterialTheme.typography.titleMedium, color = Color(0xFFEAEAF2))
                    Text(text = "W trybie offline AUREX odpowiada lokalnie bez połączenia z backendem. Funkcje AI są ograniczone.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF), modifier = Modifier.padding(top = 8.dp))
                    Switch(
                        checked = offlineMode,
                        onCheckedChange = { viewModel.setOfflineMode(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF8B5CF6), checkedTrackColor = Color(0xFF8B5CF6).copy(alpha = 0.3f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = stringResource(id = R.string.settings_voice_responses), style = MaterialTheme.typography.titleMedium, color = Color(0xFFEAEAF2), modifier = Modifier.padding(horizontal = 16.dp, top = 8.dp))
            Switch(
                checked = voiceResponses,
                onCheckedChange = { viewModel.setVoiceResponses(it) },
                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF8B5CF6), checkedTrackColor = Color(0xFF8B5CF6).copy(alpha = 0.3f))
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(text = stringResource(id = R.string.settings_data_privacy), style = MaterialTheme.typography.labelMedium, color = Color(0xFF9CA3AF), modifier = Modifier.padding(horizontal = 16.dp, top = 24.dp, bottom = 4.dp))
            Text(text = "Klucze API przechowywane są wyłącznie w Twoim backendzie. Aplikacja nie zapisuje haseł ani kluczy lokalnie.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF), modifier = Modifier.padding(horizontal = 16.dp, bottom = 8.dp))

            Spacer(modifier = Modifier.height(24.dp))

            Button(onClick = { /* wywołane z MainActivity */ }, modifier = Modifier.padding(16.dp).fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))) {
                Text(text = stringResource(id = R.string.settings_clear_chat), color = Color.White)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(text = "${stringResource(id = R.string.settings_version)} 1.0.0", style = MaterialTheme.typography.bodySmall, color = Color(0xFF6B7280), modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}
