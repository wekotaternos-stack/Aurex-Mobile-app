package com.aurex.ai.network

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

class ApiClient(private val context: Context? = null) {

    private const val TAG = "ApiClient"

    suspend fun sendChatMessage(userText: String): String {
        val prefs = context?.getSharedPreferences("aurex_settings", Context.MODE_PRIVATE)
        val backendUrl = prefs?.getString("backend_url", "https://api.twoj-backend.pl/v1") ?: "https://api.twoj-backend.pl/v1"
        val model = prefs?.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"

        val url = URL("$backendUrl/chat/completions")
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Accept", "application/json")

        val payload = """
            {
              "model": "$model",
              "messages": [
                {"role": "system", "content": "Jesteś AUREX, osobisty asystent AI na Androidzie."},
                {"role": "user", "content": "$userText"}
              ]
            }
        """.trimIndent()
        connection.doOutput = true
        connection.outputStream.use { os ->
            os.write(payload.toByteArray())
            os.flush()
        }

        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        Log.d(TAG, "Response: $body")

        val reply = extractReply(body)
        if (responseCode !in 200..299) {
            throw RuntimeException("Backend error: $responseCode")
        }
        return reply
    }

    private fun extractReply(json: String): String {
        return try {
            val start = json.indexOf("\"content\"")
            if (start == -1) return "Odpowiedź nie została wygenerowana."
            val startQuote = json.indexOf("\"", start + 10)
            val endQuote = json.indexOf("\"", startQuote + 1)
            json.substring(startQuote + 1, endQuote)
        } catch (e: Exception) {
            "Odpowiedź nie została wygenerowana."
        }
    }
}
