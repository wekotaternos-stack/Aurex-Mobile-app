package com.aurex.ai.ui.notifications

import androidx.lifecycle.ViewModel

data class NotificationItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val category: String,
    val priority: Int, // 1=niski, 2=normalny, 3=wysoki
    val timestamp: Long = System.currentTimeMillis(),
    var read: Boolean = false
)

class NotificationsViewModel : ViewModel() {

    private val _items = MutableStateFlow<List<NotificationItem>>(emptyList())
    val items: StateFlow<List<NotificationItem>> = _items.asStateFlow()

    private val _mutedCategories = MutableStateFlow<Set<String>>(emptySet())
    val mutedCategories: StateFlow<Set<String>> = _mutedCategories.asStateFlow()

    fun add(title: String, body: String, category: String, priority: Int = 2) {
        _items.value = _items.value + listOf(NotificationItem(title = title, body = body, category = category, priority = priority))
    }

    fun markRead(id: String) {
        _items.value = _items.value.map { if (it.id == id) it.copy(read = true) else it }
    }

    fun delete(id: String) {
        _items.value = _items.value.filter { it.id != id }
    }

    fun toggleMute(category: String) {
        _mutedCategories.value = if (_mutedCategories.value.contains(category)) {
            _mutedCategories.value - category
        } else {
            _mutedCategories.value + category
        }
    }

    fun isMuted(category: String): Boolean = _mutedCategories.value.contains(category)

    val categories: List<String> = listOf("Asystent", "Diagnostyka", "Przypomnienia", "Zadania")
}
