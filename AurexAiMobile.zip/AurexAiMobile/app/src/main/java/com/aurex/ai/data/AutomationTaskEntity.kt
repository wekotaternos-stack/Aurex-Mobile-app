package com.aurex.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "automation_tasks")
data class AutomationTaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String,
    val schedule: String,
    val enabled: Boolean,
    val createdAt: Long,
    val lastRun: Long?
)