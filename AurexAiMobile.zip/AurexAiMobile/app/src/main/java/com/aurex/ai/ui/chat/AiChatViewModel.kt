package com.aurex.ai.ui.chat

import android.content.Context
import android.content Intent
import android.content IntentFilter
import android.os.BatteryManager
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurex.ai.data.KnowledgeBase
import com.aurex.ai.network.ApiClient
import com.aurex.ai.ui.settings.SettingsViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class Sender { USER, AI }

class AiChatViewModel(
    private val context: Context,
    private val settings: SettingsViewModel? = null
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val apiClient = ApiClient()

    fun sendMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        _messages.value = _messages.value + listOf(ChatMessage(sender = Sender.USER, text = trimmed))
        _isSending.value = true
        _error.value = null

        viewModelScope.launch {
            try {
                val offline = settings?.offlineMode?.value ?: false
                val reply = if (offline) {
                    generateOfflineReply(trimmed)
                } else {
                    try {
                        apiClient.sendChatMessage(trimmed)
                    } catch (e: Exception) {
                        Log.e("AiChat", "Backend error: ${e.message}")
                        _error.value = "Błąd połączenia z backendem — używam odpowiedzi lokalnych."
                        generateOfflineReply(trimmed)
                    }
                }
                _messages.value = _messages.value + listOf(ChatMessage(sender = Sender.AI, text = reply))
                _isSending.value = false
            } catch (e: Exception) {
                _error.value = "Błąd: ${e.message}"
                _isSending.value = false
            }
        }
    }

    fun clearHistory() {
        _messages.value = emptyList()
        _error.value = null
    }

    private suspend fun generateOfflineReply(userText: String): String {
        val kb = KnowledgeBase()
        val matches = kb.search(userText)
        if (matches.isNotEmpty()) {
            return "Lokalna odpowiedź: ${matches.first().content}"
        }
        return when {
            userText.contains("cześć", ignoreCase = true) ||
            userText.contains("hej", ignoreCase = true) ->
                "Cześć! Jestem AUREX — tryb offline. Działam lokalnie bez połączenia z backendem."
            userText.contains("bater", ignoreCase = true) -> {
                val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 1) ?: 1
                val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
                "Stan baterii: ${if (percent >= 0) "$percent%" else "niedostępne"}. Sprawdź zakładkę Skaner."
            }
            else -> "Otrzymuję: \"$userText\". W trybie offline odpowiadam lokalnie — dla pełnej mocy AI włącz połączenie z backendem."
        }
    }
}