package com.aurex.ai.ui.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MemoryItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val category: String,
    val timestamp: Long = System.currentTimeMillis()
)

class MemoryViewModel : ViewModel() {

    private val _items = MutableStateFlow<List<MemoryItem>>(emptyList())
    val items: StateFlow<List<MemoryItem>> = _items.asStateFlow()

    private val _enabled = MutableStateFlow(true)
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun addItem(title: String, content: String, category: String) {
        if (title.isBlank() || content.isBlank()) {
            _error.value = "Tytuł i treść są wymagane"
            return
        }
        _error.value = null
        _items.value = _items.value + listOf(MemoryItem(title = title, content = content, category = category))
    }

    fun updateItem(id: String, title: String, content: String, category: String) {
        _items.value = _items.value.map {
            if (it.id == id) it.copy(title = title, content = content, category = category) else it
        }
    }

    fun deleteItem(id: String) {
        _items.value = _items.value.filter { it.id != id }
    }

    fun toggleMemory() {
        _enabled.value = !_enabled.value
    }

    fun search(query: String): List<MemoryItem> {
        if (query.isBlank()) return _items.value
        val q = query.lowercase()
        return _items.value.filter { it.title.lowercase().contains(q) || it.content.lowercase().contains(q) || it.category.lowercase().contains(q) }
    }

    val categories: List<String> = listOf("Ogólne", "Praca", "Nauka", "Zdrowie", "Finanse", "Inne")
}
