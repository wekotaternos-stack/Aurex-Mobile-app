package com.aurex.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memory_items")
data class MemoryItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val category: String,
    val timestamp: Long
)