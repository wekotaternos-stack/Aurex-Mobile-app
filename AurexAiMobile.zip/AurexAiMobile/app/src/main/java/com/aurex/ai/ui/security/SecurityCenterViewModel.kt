package com.aurex.ai.ui.security

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PermissionRow(
    val name: String,
    val label: String,
    val granted: Boolean
)

data class ActivityLogEntry(
    val time: String,
    val action: String,
    val detail: String
)

class SecurityCenterViewModel : ViewModel() {

    private val _permissions = MutableStateFlow<List<PermissionRow>>(listOf(
        PermissionRow("android.permission.RECORD_AUDIO", "Mikrofon", false),
        PermissionRow("android.permission.POST_NOTIFICATIONS", "Powiadomienia", false),
        PermissionRow("android.permission.READ_EXTERNAL_STORAGE", "Pliki i media", false),
        PermissionRow("android.permission.ACCESS_NETWORK_STATE", "Sieć", true),
        PermissionRow("android.permission.RECEIVE_BOOT_COMPLETED", "Uruchomienie przy starcie", false)
    ))
    val permissions: StateFlow<List<PermissionRow>> = _permissions.asStateFlow()

    private val _activity = MutableStateFlow<List<ActivityLogEntry>>(listOf(
        ActivityLogEntry("10:12", "Uruchomiono skan urządzenia", "Odczytano baterię, RAM, dysk, sieć"),
        ActivityLogEntry("09:45", "Czat AI", "Wysłano zapytanie do backendu"),
        ActivityLogEntry("08:30", "Asystent głosowy", "Mikrofon aktywny przez 45 s")
    ))
    val activity: StateFlow<List<ActivityLogEntry>> = _activity.asStateFlow()

    private val _encryption = MutableStateFlow(true)
    val encryption: StateFlow<Boolean> = _encryption.asStateFlow()

    fun toggleEncryption() {
        _encryption.value = !_encryption.value
    }

    fun clearAllData() {
        // W pełnej wersji: usuwa bazę Room, preferencje, pliki lokalne.
        _activity.value = emptyList()
    }

    fun stopAllServices() {
        // Sygnał do zatrzymania zadań i usług AUREX (Foreground Service, WorkManager).
    }
}
