package com.aurex.ai.ui.automation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AutomationTask(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val type: String, // "harmonogram", "przypomnienie", "raport", "reguła"
    val schedule: String,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    var lastRun: Long? = null
)

data class AutomationHistoryEntry(
    val taskId: String,
    val taskTitle: String,
    val executedAt: Long,
    val status: String // "ukonczone", "bledne", "zatrzymane"
)

class AutomationViewModel : ViewModel() {

    private val _tasks = MutableStateFlow<List<AutomationTask>>(emptyList())
    val tasks: StateFlow<List<AutomationTask>> = _tasks.asStateFlow()

    private val _history = MutableStateFlow<List<AutomationHistoryEntry>>(emptyList())
    val history: StateFlow<List<AutomationHistoryEntry>> = _history.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun addTask(title: String, type: String, schedule: String) {
        val task = AutomationTask(title = title, type = type, schedule = schedule)
        _tasks.value = _tasks.value + listOf(task)
    }

    fun toggleTask(id: String) {
        _tasks.value = _tasks.value.map { if (it.id == id) it.copy(enabled = !it.enabled) else it }
    }

    fun deleteTask(id: String) {
        _tasks.value = _tasks.value.filter { it.id != id }
    }

    fun markRun(id: String, title: String, status: String) {
        _tasks.value = _tasks.value.map {
            if (it.id == id) it.copy(lastRun = System.currentTimeMillis()) else it
        }
        _history.value = _history.value + listOf(
            AutomationHistoryEntry(taskId = id, taskTitle = title, executedAt = System.currentTimeMillis(), status = status)
        )
    }

    fun stopAll() {
        _tasks.value = _tasks.value.map { it.copy(enabled = false) }
    }
}
