package com.aurex.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: Long
)