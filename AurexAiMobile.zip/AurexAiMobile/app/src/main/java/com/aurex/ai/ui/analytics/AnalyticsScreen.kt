package com.aurex.ai.ui.analytics

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AnalyticsScreen(viewModel: AnalyticsViewModel = AnalyticsViewModel()) {
    val battery by remember { viewModel.batteryHistory }
    val memory by remember { viewModel.memoryHistory }
    val storage by remember { viewModel.storageHistory }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Analityka") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            Text(text = "Historia pomiarów", style = MaterialTheme.typography.titleMedium, color = Color(0xFFEAEAF2), modifier = Modifier.padding(horizontal = 16.dp, top = 8.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                ChipButton(label = "Tydzień", selected = true)
                ChipButton(label = "Miesiąc", selected = false)
            }

            LineChartCard(title = "Bateria", series = battery)
            LineChartCard(title = "Pamięć RAM", series = memory)
            LineChartCard(title = "Dysk", series = storage)

            Spacer(modifier = Modifier.height(16.dp))
            Text(text = viewModel.weeklyStats, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF), modifier = Modifier.padding(horizontal = 16.dp))
            Text(text = viewModel.monthlyStats, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF), modifier = Modifier.padding(horizontal = 16.dp, bottom = 16.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Button(onClick = {}) { Text(text = "Eksport danych") }
                Button(onClick = {}) { Text(text = "Raport PDF") }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "Legenda: ● rzeczywiste   ▲ szacunkowe   — brak danych", style = MaterialTheme.typography.captionSmall, color = Color(0xFF4B4B5C), modifier = Modifier.padding(horizontal = 16.dp, bottom = 16.dp))
        }
    }
}

@Composable
private fun ChipButton(label: String, selected: Boolean) {
    FilterChip(
        selected = selected,
        onCheckedChange = {},
        label = { Text(text = label) },
        colors = ChipDefaults.colors(
            containerColor = if (selected) Color(0xFF8B5CF6) else Color(0xFF1A1A28)
        )
    )
}

@Composable
private fun LineChartCard(title: String, series: HistorySeries) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161622))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = Color(0xFF8B5CF6))
            Spacer(modifier = Modifier.height(8.dp))
            Box(modifier = Modifier.fillMaxWidth().height(140.dp)) {
                LineChart(points = series.points)
                QualityLegend(points = series.points)
            }
        }
    }
}

@Composable
private fun LineChart(points: List<DataPoint>) {
    if (points.isEmpty()) return
    val maxValue = points.maxOfOrNull { it.value } ?: 1f
    val width = 260f
    val height = 100f
    val stepX = width / (points.size - 1).coerceAt(1)

    Canvas(modifier = Modifier.size(width.dp, height.dp)) {
        val centerY = size.height - 20
        // Oś pozioma
        drawLine(
            start = Offset(0f, centerY),
            end = Offset(size.width, centerY),
            color = Color(0xFF2A2A3A),
            strokeWidth = 1f
        )
        // Punkty i linia
        var prev: Offset? = null
        points.forEachIndexed { index, point ->
            val x = index * stepX
            val y = centerY - (point.value / maxValue) * (height - 40)
            val current = Offset(x, y)
            val color = when (point.quality) {
                DataQuality.ACTUAL -> Color(0xFF22D3EE)
                DataQuality.ESTIMATED -> Color(0xFFF59E0B)
                DataQuality.MISSING -> Color(0xFF4B4B5C)
            }
            drawCircle(center = current, radius = 4f, color = color)
            prev?.let { drawLine(start = it, end = current, color = color, strokeWidth = 2f) }
            prev = current
        }
        // Etykiety osi X
        points.forEachIndexed { index, point ->
            drawText(
                text = point.label,
                top = Offset(index * stepX - 10, centerY + 6),
                fontSize = 10.sp,
                color = Color(0xFF9CA3AF)
            )
        }
    }
}

@Composable
private fun QualityLegend(points: List<DataPoint>) {
    val actual = points.count { it.quality == DataQuality.ACTUAL }
    val estimated = points.count { it.quality == DataQuality.ESTIMATED }
    val missing = points.count { it.quality == DataQuality.MISSING }
    Column(
        modifier = Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 4.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(text = "●$actual ▲$estimated —$missing", style = MaterialTheme.typography.captionSmall, color = Color(0xFF4B4B5C))
    }
}
