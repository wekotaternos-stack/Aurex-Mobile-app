package com.aurex.ai.ui.voice

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.animation.Animatable
import androidx.compose.animation.animateFloatAsState
import androidx.compose.animation.infiniteRepeatable
import androidx.compose.animation.tween
import androidx.compose.animation.repeatMode

@Composable
fun VoiceWakeScreen(viewModel: VoiceWakeViewModel = VoiceWakeViewModel()) {
    val isListening by viewModel.isListening.collectAsState()
    val micActive by viewModel.micActive.collectAsState()
    val continuous by viewModel.continuousMode.collectAsState()
    val wakeWord by viewModel.wakeWordEnabled.collectAsState()
    val status by viewModel.status.collectAsState()

    val pulse by animateFloatAsState(
        targetValue = if (micActive) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = repeatMode.Reverse
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Asystent głosowy") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        },
        floatingActionButton = {
            if (isListening) {
                IconButton(onClick = { viewModel.interrupt() }) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Przerwij wypowiedź",
                        tint = Color.White
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // Wskaźnik aktywności mikrofonu (pulsujący, gdy aktywny)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 40.dp)
                    .size(120.dp)
                    .alpha(0.5f + pulse * 0.5f)
                    .background(
                        color = if (micActive) Color(0xFFEF4444) else Color(0xFF8B5CF6),
                        shape = CircleShape
                    )
                    .clip(CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Mikrofon",
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            Text(
                text = status,
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFFEAEAF2),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Duży przycisk rozmowy
            Button(
                onClick = { viewModel.toggleListening() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isListening) Color(0xFFEF4444) else Color(0xFF8B5CF6)
                ),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .width(200.dp)
                    .height(56.dp)
            ) {
                Text(
                    text = if (isListening) "Naciśnij, by zakończyć" else "Naciśnij i mów",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(horizontal = 32.dp)
            ) {
                Switch(
                    checked = continuous,
                    onCheckedChange = { viewModel.toggleContinuous() },
                    modifier = Modifier.align(Alignment.CenterVertically)
                )
                Text(
                    text = "Tryb rozmowy ciągłej",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF9CA3AF),
                    modifier = Modifier.padding(start = 12.dp).align(Alignment.CenterVertically)
                )
            }

            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(horizontal = 32.dp)
                    .top(12.dp)
            ) {
                Switch(
                    checked = wakeWord,
                    onCheckedChange = { viewModel.toggleWakeWord() },
                    modifier = Modifier.align(Alignment.CenterVertically)
                )
                Text(
                    text = "Wake 24/7 (hasło głosowe)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF9CA3AF),
                    modifier = Modifier.padding(start = 12.dp).align(Alignment.CenterVertically)
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            Text(
                text = "Uprawnienie mikrofonu (RECORD_AUDIO) wymagane. Android może ograniczyć działanie w tle.",
                style = MaterialTheme.typography.captionSmall,
                color = Color(0xFF4B4B5C),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 24.dp)
                    .widthIn(max = 280.dp)
                    .textAlign(androidx.compose.ui.text.TextAlign.Center)
            )
        }
    }
}
