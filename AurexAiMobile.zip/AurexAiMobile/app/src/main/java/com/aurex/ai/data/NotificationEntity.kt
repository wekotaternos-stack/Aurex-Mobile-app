package com.aurex.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notification_items")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val category: String,
    val priority: Int,
    val timestamp: Long,
    val read: Boolean
)