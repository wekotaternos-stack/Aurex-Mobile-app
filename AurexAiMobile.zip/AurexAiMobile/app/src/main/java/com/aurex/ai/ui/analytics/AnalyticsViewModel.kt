package com.aurex.ai.ui.analytics

import androidx.lifecycle.ViewModel

data class DataPoint(
    val label: String,
    val value: Float,
    val quality: DataQuality // rzeczywiste / szacunkowe / brak
)

enum class DataQuality { ACTUAL, ESTIMATED, MISSING }

data class HistorySeries(
    val name: String,
    val points: List<DataPoint>
)

class AnalyticsViewModel : ViewModel() {

    // Przykładowe serie historyczne — w wersji produkcyjnej wypełniane z Room/historii skanów.
    val batteryHistory: HistorySeries = HistorySeries(
        name = "Bateria (%)",
        points = listOf(
            DataPoint("Pon", 78f, DataQuality.ACTUAL),
            DataPoint("Wt", 65f, DataQuality.ACTUAL),
            DataPoint("Śr", 52f, DataQuality.ACTUAL),
            DataPoint("Czw", 40f, DataQuality.ESTIMATED),
            DataPoint("Pt", 30f, DataQuality.MISSING),
            DataPoint("Sob", 85f, DataQuality.ACTUAL),
            DataPoint("Niedz", 70f, DataQuality.ACTUAL)
        )
    )

    val memoryHistory: HistorySeries = HistorySeries(
        name = "RAM wolne (%)",
        points = listOf(
            DataPoint("Pon", 45f, DataQuality.ACTUAL),
            DataPoint("Wt", 38f, DataQuality.ACTUAL),
            DataPoint("Śr", 33f, DataQuality.ACTUAL),
            DataPoint("Czw", 28f, DataQuality.ESTIMATED),
            DataPoint("Pt", 22f, DataQuality.MISSING),
            DataPoint("Sob", 50f, DataQuality.ACTUAL),
            DataPoint("Niedz", 48f, DataQuality.ACTUAL)
        )
    )

    val storageHistory: HistorySeries = HistorySeries(
        name = "Dysk wolny (%)",
        points = listOf(
            DataPoint("Pon", 60f, DataQuality.ACTUAL),
            DataPoint("Wt", 58f, DataQuality.ACTUAL),
            DataPoint("Śr", 55f, DataQuality.ACTUAL),
            DataPoint("Czw", 53f, DataQuality.ACTUAL),
            DataPoint("Pt", 50f, DataQuality.ACTUAL),
            DataPoint("Sob", 48f, DataQuality.ACTUAL),
            DataPoint("Niedz", 45f, DataQuality.ACTUAL)
        )
    )

    val weeklyStats = "Średni poziom baterii (tydzień): 60% • Średnie wolne RAM: 38% • Wolne miejsce na dysku: 53%"
    val monthlyStats = "Średni poziom baterii (miesiąc): 58% • Średnie wolne RAM: 36% • Wolne miejsce na dysku: 51%"
}
