package com.aurex.ai.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.net.ConnectivityManager
import android.os.storage.StorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DeviceInfo(
    val model: String,
    val manufacturer: String,
    val androidVersion: String,
    val apiLevel: Int
)

data class CpuInfo(
    val availableProcessors: Int,
    val loadAverage: String
)

data class MemoryInfo(
    val totalBytes: Long,
    val availableBytes: Long,
    val usedBytes: Long
)

data class StorageInfo(
    val totalBytes: Long,
    val freeBytes: Long,
    val usedBytes: Long
)

data class BatteryInfo(
    val levelPercent: Int,
    val isCharging: Boolean,
    val temperatureCelsius: Float?,
    val health: Int
)

data class NetworkInfo(
    val isConnected: Boolean,
    val typeName: String?
)

data class AppInfo(
    val packageName: String,
    val appName: String?,
    val versionName: String?,
    val isSystem: Boolean
)

data class PermissionStatus(
    val name: String,
    val granted: Boolean
)

data class HealthReport(
    val score: Int, // 0-100
    val issues: List<String>
)

data class ScanResult(
    val timestamp: Long,
    val device: DeviceInfo,
    val cpu: CpuInfo,
    val memory: MemoryInfo,
    val storage: StorageInfo,
    val battery: BatteryInfo,
    val network: NetworkInfo,
    val apps: List<AppInfo>,
    val permissions: List<PermissionStatus>,
    val health: HealthReport
)

class DeviceRepository(private val context: Context) {

    suspend fun scanDevice(): ScanResult = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()
        ScanResult(
            timestamp = timestamp,
            device = getDeviceInfo(),
            cpu = getCpuInfo(),
            memory = getMemoryInfo(),
            storage = getStorageInfo(),
            battery = getBatteryInfo(),
            network = getNetworkInfo(),
            apps = getInstalledApps(),
            permissions = getPermissionStatuses(),
            health = computeHealthScore()
        )
    }

    private fun getDeviceInfo(): DeviceInfo {
        return DeviceInfo(
            model = Build.MODEL,
            manufacturer = Build.MANUFACTURER,
            androidVersion = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT
        )
    }

    private fun getCpuInfo(): CpuInfo {
        val available = Runtime.getRuntime().availableProcessors()
        val load = java.lang.management.ManagementFactory.getOperatingSystemMXBean()
            .systemLoadAverage?.toString() ?: "n/d"
        return CpuInfo(availableProcessors = available, loadAverage = load)
    }

    private fun getMemoryInfo(): MemoryInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return MemoryInfo(
            totalBytes = info.totalMem,
            availableBytes = info.availMem,
            usedBytes = info.totalMem - info.availMem
        )
    }

    private fun getStorageInfo(): StorageInfo {
        val root = Environment.getDataDirectory()
        val stat = StatFs(root.path)
        val total = stat.blockSizeLong * stat.blockCountLong
        val free = stat.blockSizeLong * stat.availableBlocksLong
        return StorageInfo(
            totalBytes = total,
            freeBytes = free,
            usedBytes = total - free
        )
    }

    private fun getBatteryInfo(): BatteryInfo {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 1) ?: 1
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val tempRaw = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val temp = if (tempRaw != null && tempRaw != -1) tempRaw / 10f else null
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN) ?: -1
        return BatteryInfo(percent, plugged, temp, health)
    }

    private fun getNetworkInfo(): NetworkInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val capabilities = cm.getNetworkCapabilities(network)
        val connected = capabilities != null && capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val typeName = if (capabilities != null) capabilities.transportTypeNames.joinToString(",") else null
        return NetworkInfo(connected, typeName)
    }

    private fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        return apps.map { appInfo ->
            AppInfo(
                packageName = appInfo.packageName,
                appName = pm.getApplicationLabel(appInfo)?.toString(),
                versionName = try {
                    pm.getPackageInfo(appInfo.packageName, 0).versionName
                } catch (e: Exception) {
                    null
                },
                isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }.sortedBy { it.appName ?: "" }
    }

    private fun getPermissionStatuses(): List<PermissionStatus> {
        val pm = context.packageManager
        val permissions = listOf(
            "android.permission.RECORD_AUDIO",
            "android.permission.INTERNET",
            "android.permission.ACCESS_NETWORK_STATE",
            "android.permission.POST_NOTIFICATIONS",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.RECEIVE_BOOT_COMPLETED"
        )
        return permissions.map { name ->
            PermissionStatus(
                name = name,
                granted = pm.checkPermission(name, context.packageName) == PackageManager.PERMISSION_GRANTED
            )
        }
    }

    private fun computeHealthScore(): HealthReport {
        val issues = mutableListOf<String>()
        var score = 100
        val battery = getBatteryInfo()
        if (battery.levelPercent >= 0 && battery.levelPercent < 20) {
            issues.add("Niski poziom baterii (${battery.levelPercent}%)")
            score -= 20
        }
        val memory = getMemoryInfo()
        val ramFreePercent = if (memory.totalBytes > 0) (memory.availableBytes.toDouble() / memory.totalBytes) else 1.0
        if (ramFreePercent < 0.1) {
            issues.add("Mało wolnej pamięci RAM")
            score -= 15
        }
        val storage = getStorageInfo()
        val storageFreePercent = if (storage.totalBytes > 0) (storage.freeBytes.toDouble() / storage.totalBytes) else 1.0
        if (storageFreePercent < 0.1) {
            issues.add("Mało wolnego miejsca na dysku")
            score -= 15
        }
        if (!getNetworkInfo().isConnected) {
            issues.add("Brak połączenia z internetem")
            score -= 10
        }
        return HealthReport(score = score.coerceAt(0, 100), issues = issues)
    }
}
