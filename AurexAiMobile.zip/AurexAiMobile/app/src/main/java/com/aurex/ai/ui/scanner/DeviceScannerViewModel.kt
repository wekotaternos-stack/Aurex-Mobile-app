package com.aurex.ai.ui.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurex.ai.data.DeviceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DeviceScannerViewModel(private val repository: DeviceRepository) : ViewModel() {

    private val _result = MutableStateFlow<com.aurex.ai.data.ScanResult?>(null)
    val result: StateFlow<com.aurex.ai.data.ScanResult?> = _result.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun runScan(androidContext: android.content.Context) {
        _isScanning.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val scan = repository.scanDevice()
                _result.value = scan
            } catch (e: Exception) {
                _error.value = e.message ?: "Błąd skanowania"
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun exportReport(): String {
        val scan = _result.value ?: return "Brak danych do eksportu."
        val sb = StringBuilder()
        sb.append("AUREX AI — Raport diagnostyczny urządzenia\n")
        sb.append("Data: ${java.time.Instant.ofEpochMilli(scan.timestamp).toString()}\n\n")
        sb.append("URZĄDZENIE\n")
        sb.append("Model: ${scan.device.model}\n")
        sb.append("Producent: ${scan.device.manufacturer}\n")
        sb.append("Android: ${scan.device.androidVersion} (API ${scan.device.apiLevel})\n\n")
        sb.append("PROCESOR\n")
        sb.append("Rdzenie: ${scan.cpu.availableProcessors}\n")
        sb.append("Obciążenie: ${scan.cpu.loadAverage}\n\n")
        sb.append("PAMIĘĆ RAM\n")
        sb.append("Całkowita: ${formatBytes(scan.memory.totalBytes)}\n")
        sb.append("Dostępna: ${formatBytes(scan.memory.availableBytes)}\n")
        sb.append("Używana: ${formatBytes(scan.memory.usedBytes)}\n\n")
        sb.append("PAMIĘĆ WEWNĘTRZNA\n")
        sb.append("Całkowita: ${formatBytes(scan.storage.totalBytes)}\n")
        sb.append("Wolna: ${formatBytes(scan.storage.freeBytes)}\n")
        sb.append("Używana: ${formatBytes(scan.storage.usedBytes)}\n\n")
        sb.append("BATERIA\n")
        sb.append("Poziom: ${scan.battery.levelPercent}%\n")
        sb.append("Ładowanie: ${scan.battery.isCharging}\n")
        sb.append("Temperatura: ${scan.battery.temperatureCelsius?.let { "$it °C" } ?: "n/d"}\n\n")
        sb.append("SIEC\n")
        sb.append("Połączono: ${scan.network.isConnected}\n")
        sb.append("Typ: ${scan.network.typeName ?: "n/d"}\n\n")
        sb.append("APLIKACJE (${scan.apps.size})\n")
        scan.apps.take(20).forEach { sb.append("- ${it.appName ?: it.packageName}\n") }
        sb.append("\nUPRAWNIENIA\n")
        scan.permissions.forEach { sb.append("- ${it.name}: ${if (it.granted) "przyznane" else "odmówione"}\n") }
        sb.append("\nKONDYCJA\n")
        sb.append("Wynik: ${scan.health.score}/100\n")
        scan.health.issues.forEach { sb.append("- $it\n") }
        return sb.toString()
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val exp = (Math.log(bytes.toDouble()) / Math.log(1024.0)).toInt()
        val pre = arrayOf("B", "KB", "MB", "GB", "TB")
        return String.format("%.2f %s", bytes / Math.pow(1024.0, exp.toDouble()), pre[exp.coerceAt(0, 4)])
    }
}
