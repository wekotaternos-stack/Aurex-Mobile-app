package com.aurex.ai.ui.manager

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ManagerAppItem(
    val packageName: String,
    val appName: String?,
    val iconRes: Int,
    val isSystem: Boolean
)

class DeviceManagerViewModel(private val context: Context) : ViewModel() {

    private val _apps = MutableStateFlow<List<ManagerAppItem>>(emptyList())
    val apps: StateFlow<List<ManagerAppItem>> = _apps.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun loadApps() {
        viewModelScope.launch {
            try {
                val pm = context.packageManager
                val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                val items = apps.map { ai ->
                    ManagerAppItem(
                        packageName = ai.packageName,
                        appName = pm.getApplicationLabel(ai)?.toString(),
                        iconRes = ai.icon,
                        isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    )
                }.sortedBy { it.appName ?: "" }
                _apps.value = items
            } catch (e: Exception) {
                _error.value = e.message ?: "Błąd ładowania aplikacji"
            }
        }
    }

    fun openApp(packageName: String): Boolean {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun openAppSettings(packageName: String): Boolean {
        val pm = context.packageManager
        try {
            val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(android.net.Uri.fromParts("package", packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return true
        } catch (e: Exception) {
            _error.value = e.message ?: "Nie można otworzyć ustawień aplikacji"
            return false
        }
    }

    fun openSystemSettings() {
        val intent = Intent(android.provider.Settings.ACTION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
