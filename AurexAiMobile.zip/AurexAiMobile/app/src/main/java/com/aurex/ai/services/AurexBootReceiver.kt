package com.aurex.ai.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AurexBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "android.intent.action.BOOT_COMPLETED") {
            Log.d("AurexBoot", "Boot completed — wznawianie dozwolonych zadań")
            // W pełnej wersji: wznawianie WorkManagera, Foreground Service itp.
            // Android ogranicza ponowne uruchomienie usług po restarcie —
            // dozwolone jest tylko to, co ma odpowiednie uprawnienia (RECEIVE_BOOT_COMPLETED).
        }
    }
}