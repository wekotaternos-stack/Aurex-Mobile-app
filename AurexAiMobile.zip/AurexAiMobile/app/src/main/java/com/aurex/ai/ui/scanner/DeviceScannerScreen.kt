package com.aurex.ai.ui.scanner

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aurex.ai.data.ScanResult

@Composable
fun DeviceScannerScreen(
    viewModel: DeviceScannerViewModel,
    context: Context = LocalContext.current
) {
    val result by viewModel.result.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val error by viewModel.error.collectAsState()
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Skaner urządzenia") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { scope.launch { viewModel.runScan(context) } },
                enabled = !isScanning,
                icon = { Icon(imageVector = androidx.compose.material.Icons.Default.PlayCircle, contentDescription = "Skanuj") },
                text = { Text(if (isScanning) "Skanowanie…" else "Uruchom skan") }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            if (isScanning) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            error?.let {
                Text(text = it, color = Color(0xFFEF4444), modifier = Modifier.padding(horizontal = 16.dp, top = 4.dp))
            }
            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                item { DiagnosticCard(title = "Urządzenie") {
                    result?.let { scan ->
                        Column {
                            Text(text = "${scan.device.manufacturer} ${scan.device.model}", style = MaterialTheme.typography.bodyLarge, color = Color(0xFFEAEAF2))
                            Text(text = "Android ${scan.device.androidVersion} (API ${scan.device.apiLevel})", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
                        }
                    } ?: run {
                        Text(text = "Uruchom skan, aby zobaczyć dane", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C))
                    }
                }}
                item { DiagnosticCard(title = "Procesor") {
                    result?.let { scan ->
                        Column {
                            Text(text = "Rdzenie: ${scan.cpu.availableProcessors}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                            Text(text = "Obciążenie: ${scan.cpu.loadAverage}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
                        }
                    } ?: run {
                        Text(text = "—", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C))
                    }
                }}
                item { DiagnosticCard(title = "Pamięć RAM") {
                    result?.let { scan ->
                        Column {
                            Text(text = "Dostępna: ${formatBytes(scan.memory.availableBytes)} / ${formatBytes(scan.memory.totalBytes)}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                            Text(text = "Używana: ${formatBytes(scan.memory.usedBytes)}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
                        }
                    } ?: run {
                        Text(text = "—", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C))
                    }
                }}
                item { DiagnosticCard(title = "Pamięć wewnętrzna") {
                    result?.let { scan ->
                        Column {
                            Text(text = "Wolna: ${formatBytes(scan.storage.freeBytes)} / ${formatBytes(scan.storage.totalBytes)}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                            Text(text = "Używana: ${formatBytes(scan.storage.usedBytes)}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
                        }
                    } ?: run {
                        Text(text = "—", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C))
                    }
                }}
                item { DiagnosticCard(title = "Bateria") {
                    result?.let { scan ->
                        Column {
                            Text(text = "Poziom: ${scan.battery.levelPercent}%", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                            Text(text = "Ładowanie: ${if (scan.battery.isCharging) "tak" else "nie"}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
                        }
                    } ?: run {
                        Text(text = "—", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C))
                    }
                }}
                item { DiagnosticCard(title = "Sieć") {
                    result?.let { scan ->
                        Column {
                            Text(text = "Połączono: ${if (scan.network.isConnected) "tak" else "nie"}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                            Text(text = scan.network.typeName ?: "n/d", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
                        }
                    } ?: run {
                        Text(text = "—", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C))
                    }
                }}
                item { DiagnosticCard(title = "Kondycja") {
                    result?.let { scan ->
                        Column {
                            Text(text = "Wynik: ${scan.health.score}/100", style = MaterialTheme.typography.bodyLarge, color = Color(0xFFEAEAF2))
                            if (scan.health.issues.isNotEmpty()) {
                                Text(text = scan.health.issues.joinToString("\n"), style = MaterialTheme.typography.bodySmall, color = Color(0xFFF59E0B))
                            } else {
                                Text(text = "Brak wykrytych problemów", style = MaterialTheme.typography.bodySmall, color = Color(0xFF10B981))
                            }
                        }
                    } ?: run {
                        Text(text = "—", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C))
                    }
                }}
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                    ) {
                        Button(onClick = { scope.launch { viewModel.runScan(context) } }, enabled = !isScanning) {
                            Text("Odśwież")
                        }
                        Button(onClick = {
                            val report = viewModel.exportReport()
                            androidx.compose.runtime.remember { }
                            android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_TEXT, report)
                            }.let { intent ->
                                val chooser = android.content.Intent.createChooser(intent, "Eksport raportu")
                                context.startActivity(chooser)
                            }
                        }) {
                            Text("Eksport")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161622))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = Color(0xFF8B5CF6))
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val exp = (Math.log(bytes.toDouble()) / Math.log(1024.0)).toInt()
    val pre = arrayOf("B", "KB", "MB", "GB", "TB")
    return String.format("%.2f %s", bytes / Math.pow(1024.0, exp.toDouble()), pre[exp.coerceAt(0, 4)])
}
