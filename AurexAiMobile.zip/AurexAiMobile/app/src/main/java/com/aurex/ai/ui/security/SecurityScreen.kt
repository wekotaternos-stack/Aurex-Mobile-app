package com.aurex.ai.ui.security

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun SecurityScreen(viewModel: SecurityCenterViewModel = SecurityCenterViewModel()) {
    val permissions by viewModel.permissions.collectAsState()
    val activity by viewModel.activity.collectAsState()
    val encryption by viewModel.encryption.collectAsState()
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Centrum bezpieczeństwa") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            Text(text = "Uprawnienia AUREX", style = MaterialTheme.typography.titleMedium, color = Color(0xFFEAEAF2), modifier = Modifier.padding(horizontal = 16.dp, top = 8.dp))
            LazyColumn(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = permissions, key = { it.name }) { p ->
                    PermissionRowItem(permission = p)
                }
            }

            Divider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = androidx.compose.foundation.layout.Alignment.CenterVertically
            ) {
                Switch(checked = encryption, onCheckedChange = { viewModel.toggleEncryption() })
                Text(text = "Szyfrowanie danych lokalnych", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                Spacer(modifier = Modifier.weight(1f))
                Text(text = if (encryption) "Włączone" else "Wyłączone", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF))
            }

            Divider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))

            Text(text = "Historia działań asystenta", style = MaterialTheme.typography.titleMedium, color = Color(0xFFEAEAF2), modifier = Modifier.padding(horizontal = 16.dp, top = 8.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = activity, key = { it.time }) { entry ->
                    ActivityRow(entry = entry)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Button(onClick = { viewModel.clearAllData() }) {
                    Text(text = "Wyczyść wszystkie dane")
                }
                Button(
                    onClick = { viewModel.stopAllServices() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text(text = "STOP ALL — zatrzymaj wszystko", color = Color.White)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun PermissionRowItem(permission: PermissionRow) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = androidx.compose.foundation.layout.Alignment.CenterVertically
    ) {
        Text(text = permission.label, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
        Spacer(modifier = Modifier.weight(1f))
        Text(
            text = if (permission.granted) "Przyznane" else "Wymagane",
            style = MaterialTheme.typography.bodySmall,
            color = if (permission.granted) Color(0xFF10B981) else Color(0xFFF59E0B)
        )
    }
}

@Composable
private fun ActivityRow(entry: ActivityLogEntry) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = androidx.compose.foundation.layout.Alignment.CenterVertically
    ) {
        Text(text = entry.time, style = MaterialTheme.typography.bodySmall, color = Color(0xFF4B4B5C))
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = entry.action, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
            Text(text = entry.detail, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF))
        }
    }
}
