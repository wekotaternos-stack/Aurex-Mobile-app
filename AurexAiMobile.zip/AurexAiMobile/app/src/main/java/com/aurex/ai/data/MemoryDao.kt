package com.aurex.ai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory_items ORDER BY timestamp DESC")
    fun getAllItems(): Flow<List<MemoryItemEntity>>

    @Insert
    suspend fun insert(item: MemoryItemEntity)

    @Update
    suspend fun update(item: MemoryItemEntity)

    @Delete
    fun delete(item: MemoryItemEntity)

    @Query("DELETE FROM memory_items")
    fun clearAll()

    @Query("SELECT * FROM memory_items WHERE id = :id")
    fun getItemById(id: String): Flow<MemoryItemEntity?>