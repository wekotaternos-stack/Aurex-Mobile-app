package com.aurex.ai.data

import android.content.Context
import android.content.SharedPreferences

class KnowledgeBase(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("aurex_knowledge", Context.MODE_PRIVATE)

    private val baseEntries: List<Triple<String, String, String>> = listOf(
        Triple("bateria", "Bateria", "AUREX skanuje stan baterii przez BatteryManager i raportuje kondycję urządzenia."),
        Triple("wifi", "Sieć", "AUREX sprawdza połączenie sieciowe przez ConnectivityManager."),
        Triple("pamięć", "Pamięć", "AUREX monitoruje pamięć RAM i wewnętrzną pamięć telefonu."),
        Triple("skaner", "Diagnostyka", "AUREX wykonuje skan diagnostyczny telefonu i generuje raporty kondycji.")
    )

    fun search(query: String): List<KnowledgeBaseEntry> {
        val q = query.lowercase()
        return baseEntries
            .filter { it.first.contains(q, ignoreCase = true) || it.second.contains(q, ignoreCase = true) || it.third.contains(q, ignoreCase = true) }
            .map { KnowledgeBaseEntry(category = it.second, content = it.third) }
    }

    data class KnowledgeBaseEntry(
        val category: String,
        val content: String
    )
}
