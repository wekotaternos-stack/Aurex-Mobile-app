package com.aurex.ai.ui.memory

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun MemoryScreen(viewModel: MemoryViewModel = MemoryViewModel()) {
    val items by viewModel.items.collectAsState()
    val enabled by viewModel.enabled.collectAsState()
    val error by viewModel.error.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Ogólne") }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    val filtered = viewModel.search(searchQuery)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Pamięć AUREX") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(imageVector = androidx.compose.material.Icons.Default.Add, contentDescription = "Zapamiętaj informację")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            error?.let {
                Text(text = it, color = Color(0xFFEF4444), modifier = Modifier.padding(horizontal = 16.dp, top = 4.dp))
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = androidx.compose.foundation.layout.Alignment.CenterVertically
            ) {
                Switch(checked = enabled, onCheckedChange = { viewModel.toggleMemory() })
                Text(text = if (enabled) "Pamięć włączona" else "Pamięć wyłączona", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
                Spacer(modifier = Modifier.weight(1f))
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Szukaj w pamięci…") },
                    singleLine = true,
                    modifier = Modifier.width(160.dp),
                    colors = TextFieldDefaults.colors(unfocusedContainerColor = Color(0xFF161622), focusedContainerColor = Color(0xFF1A1A28))
                )
            }
            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = filtered, key = { it.id }) { item ->
                    MemoryRow(item = item, onDelete = { viewModel.deleteItem(item.id) })
                }
            }
            if (filtered.isEmpty()) {
                Text(text = "Brak zapisanych informacji", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C), modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 24.dp))
            }
        }
    }

    if (showAdd) {
        AddMemoryDialog(
            onDismiss = { showAdd = false },
            onConfirm = { title, content, category ->
                viewModel.addItem(title, content, category)
                showAdd = false
                newTitle = ""
                newContent = ""
            },
            title = newTitle,
            content = newContent,
            category = newCategory,
            categories = viewModel.categories,
            onTitleChange = { newTitle = it },
            onContentChange = { newContent = it },
            onCategoryChange = { newCategory = it }
        )
    }
}

@Composable
private fun MemoryRow(item: MemoryItem, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161622))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(text = item.title, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                Spacer(modifier = Modifier.weight(1f))
                Chip(
                    label = { Text(text = item.category, style = MaterialTheme.typography.captionSmall) },
                    colors = ChipDefaults.chipColors(containerColor = Color(0xFF2E1B4D))
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = item.content, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF))
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End
            ) {
                Text(text = java.time.Instant.ofEpochMilli(item.timestamp).toString().substring(0, 16), style = MaterialTheme.typography.captionSmall, color = Color(0xFF4B4B5C))
                IconButton(onClick = onDelete) {
                    Icon(imageVector = androidx.compose.material.Icons.Default.Delete, contentDescription = "Usuń")
                }
            }
        }
    }
}

@Composable
private fun AddMemoryDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit,
    title: String,
    content: String,
    category: String,
    categories: List<String>,
    onTitleChange: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Zapamiętaj informację") },
        text = {
            Column(modifier = Modifier.width(280.dp)) {
                TextField(value = title, onValueChange = onTitleChange, label = { Text("Tytuł") })
                Spacer(modifier = Modifier.height(8.dp))
                TextField(value = content, onValueChange = onContentChange, label = { Text("Treść") }, singleLine = false, maxLines = 3)
                Spacer(modifier = Modifier.height(8.dp))
                DropdownMenu(
                    expanded = true,
                    onDismissRequest = {},
                    modifier = Modifier.fillMaxWidth()
                ) {
                    categories.forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(text = cat) },
                            onClick = { onCategoryChange(cat) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(title, content, category) }) { Text(text = "Zapisz") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(text = "Anuluj") }
        }
    )
}
