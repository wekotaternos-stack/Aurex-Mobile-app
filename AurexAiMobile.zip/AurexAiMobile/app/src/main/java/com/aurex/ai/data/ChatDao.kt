package com.aurex.ai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Insert
    fun insert(message: ChatMessageEntity)

    @Delete
    fun delete(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages")
    fun clearAll()

    @Query("SELECT * FROM chat_messages WHERE id = :id")
    fun getMessageById(id: String): Flow<ChatMessageEntity?>
}