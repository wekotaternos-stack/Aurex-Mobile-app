package com.aurex.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "automation_history_entries")
data class AutomationHistoryEntryEntity(
    @PrimaryKey val id: String,
    val taskId: String,
    val taskTitle: String,
    val executedAt: Long,
    val status: String
)