package com.aurex.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.aurex.ai.ui.chat.AiChatScreen
import com.aurex.ai.ui.settings.SettingsViewModel
import com.aurex.ai.ui.voice.VoiceWakeScreen
import com.aurex.ai.ui.scanner.DeviceScannerScreen
import com.aurex.ai.ui.manager.DeviceManagerScreen
import com.aurex.ai.ui.automation.AutomationScreen
import com.aurex.ai.ui.analytics.AnalyticsScreen
import com.aurex.ai.ui.memory.MemoryScreen
import com.aurex.ai.ui.notifications.NotificationsScreen
import com.aurex.ai.ui.security.SecurityScreen
import com.aurex.ai.ui.settings.SettingsScreen
import com.aurex.ai.data.DeviceRepository
import com.aurex.ai.ui.scanner.DeviceScannerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = ColorScheme(
                primary = Color(0xFF8B5CF6),
                secondary = Color(0xFF3B82F6),
                tertiary = Color(0xFF06B6D4),
                background = Color(0xFF0A0A0F),
                surface = Color(0xFF12121C),
                onBackground = Color(0xFFEAEAF2),
                onSurface = Color(0xFFEAEAF2)
            )) {
                AppNavigation()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation() {
    val navItems = listOf(
        NavItem("Home", "Home"),
        NavItem("AI Chat", "AI Chat"),
        NavItem("Voice", "Głos / Wake"),
        NavItem("Scanner", "Skaner"),
        NavItem("Manager", "Manager"),
        NavItem("Automation", "Automatyzacja"),
        NavItem("Analytics", "Analityka"),
        NavItem("Memory", "Pamięć"),
        NavItem("Notifications", "Powiadomienia"),
        NavItem("Security", "Bezpieczeństwo"),
        NavItem("Settings", "Ustawienia")
    )
    var selected by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF12121C)) {
                navItems.forEachIndexed { index, item ->
                    NavigationItem(
                        icon = { Text(text = item.label, style = MaterialTheme.typography.labelSmall) },
                        label = { Text(text = item.label) },
                        selected = selected == index,
                        onClick = { selected = index }
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selected) {
                0 -> HomeScreen()
                1 -> AiChatScreen(
                    viewModel = AiChatViewModel(LocalContext.current, SettingsViewModel(LocalContext.current)),
                    settingsViewModel = SettingsViewModel(LocalContext.current)
                )
                2 -> VoiceWakeScreen()
                3 -> DeviceScannerScreen(viewModel = DeviceScannerViewModel(DeviceRepository(LocalContext.current)))
                4 -> DeviceManagerScreen()
                5 -> AutomationScreen()
                6 -> AnalyticsScreen()
                7 -> MemoryScreen()
                8 -> NotificationsScreen()
                9 -> SecurityScreen()
                10 -> SettingsScreen(SettingsViewModel(LocalContext.current))
            }
        }
    }
}

data class NavItem(val label: String, val route: String)

@Composable
fun HomeScreen() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "AUREX AI", style = MaterialTheme.typography.headlineLarge, color = Color(0xFF8B5CF6))
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Twój osobisty asystent AI — available through całą dobę", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9CA3AF))
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = {}) {
            Text(text = "Porozmawiaj z AI")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {}) {
            Text(text = "Skanuj urządzenie")
        }
    }
}