package com.aurex.ai.ui.chat

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurex.ai.ui.settings.SettingsViewModel
import kotlinx.coroutines.launch

@Composable
fun AiChatScreen(
    viewModel: AiChatViewModel = AiChatViewModel(LocalContext.current, SettingsViewModel(LocalContext.current)),
    settingsViewModel: SettingsViewModel = SettingsViewModel(LocalContext.current)
) {
    val messages by viewModel.messages.collectAsState()
    val isSending by viewModel.isSending.collectAsState()
    val error by viewModel.error.collectAsState()
    var input by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = stringResource(id = R.string.ai_chat_title)) },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        },
        floatingActionButton = {
            if (error != null) {
                IconButton(onClick = { viewModel.clearHistory() }) {
                    Text(text = "🗑️", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = messages, key = { it.id }) { msg ->
                    ChatBubble(message = msg)
                }
            }
            if (isSending) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            error?.let {
                Text(text = it, color = Color(0xFFEF4444), modifier = Modifier.padding(horizontal = 16.dp, top = 4.dp))
            }
            ChatInput(
                input = input,
                onInputChange = { input = it },
                onSend = {
                    scope.launch { viewModel.sendMessage(input) }
                    input = ""
                },
                enabled = !isSending
            )
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    val isUser = message.sender == Sender.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 4.dp)
                .widthIn(max = 70.percent)
        ) {
            Text(
                text = message.text,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isUser) Color.White else Color(0xFFEAEAF2),
                modifier = Modifier
                    .padding(12.dp)
                    .background(
                        color = if (isUser) Color(0xFF8B5CF6) else Color(0xFF1A1A28),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clipToBounds()
                    .then(
                        if (isUser) Modifier.align(Alignment.End) else Modifier.align(Alignment.Start)
                    )
            )
            Text(
                text = java.time.Instant.ofEpochMilli(message.timestamp)
                    .atZone(java.time.ZoneId.systemDefault())
                    .toLocalTime()
                    .toString().substring(0, 5),
                style = MaterialTheme.typography.captionSmall,
                color = Color(0xFF9CA3AF),
                modifier = Modifier.padding(horizontal = 12.dp, top = 2.dp)
                    .then(if (isUser) Modifier.align(Alignment.End) else Modifier.align(Alignment.Start))
            )
        }
    }
}

@Composable
private fun ChatInput(
    input: String,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    enabled: Boolean
) {
    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        TextField(
            value = input,
            onValueChange = onInputChange,
            label = { Text(text = stringResource(id = R.string.ai_chat_input)) },
            singleLine = false,
            maxLines = 3,
            modifier = Modifier
                .fillMaxWidth()
                .padding(end = 80.dp),
            colors = TextFieldDefaults.colors(
                unfocusedContainerColor = Color(0xFF161622),
                focusedContainerColor = Color(0xFF1A1A28)
            )
        )
                IconButton(
                    onClick = onSend,
                    enabled = enabled && input.isNotEmpty()
                ) {
                    Text(
                        text = "➤",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (enabled && input.isNotEmpty()) Color(0xFF8B5CF6) else Color(0xFF4B4B5C)
                    )
                }
    }
}
