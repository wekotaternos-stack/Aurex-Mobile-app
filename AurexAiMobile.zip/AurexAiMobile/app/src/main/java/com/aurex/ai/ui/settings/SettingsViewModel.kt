package com.aurex.ai.ui.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(private val context: Context) : ViewModel() {

    private val prefs: SharedPreferences = context.getSharedPreferences("aurex_settings", Context.MODE_PRIVATE)

    private val _backendUrl = MutableStateFlow(prefs.getString("backend_url", "https://api.twoj-backend.pl/v1"))
    val backendUrl: StateFlow<String> = _backendUrl.asStateFlow()

    private val _model = MutableStateFlow(prefs.getString("model", "gpt-4o-mini"))
    val model: StateFlow<String> = _model.asStateFlow()

    private val _offlineMode = MutableStateFlow(prefs.getBoolean("offline_mode", false))
    val offlineMode: StateFlow<Boolean> = _offlineMode.asStateFlow()

    private val _voiceResponses = MutableStateFlow(prefs.getBoolean("voice_responses", true))
    val voiceResponses: StateFlow<Boolean> = _voiceResponses.asStateFlow()

    fun setBackendUrl(url: String) {
        _backendUrl.value = url
        prefs.edit().putString("backend_url", url).apply()
    }

    fun setModel(model: String) {
        _model.value = model
        prefs.edit().putString("model", model).apply()
    }

    fun setOfflineMode(enabled: Boolean) {
        _offlineMode.value = enabled
        prefs.edit().putBoolean("offline_mode", enabled).apply()
    }

    fun setVoiceResponses(enabled: Boolean) {
        _voiceResponses.value = enabled
        prefs.edit().putBoolean("voice_responses", enabled).apply()
    }
}