package com.aurex.ai.ui.notifications

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun NotificationsScreen(viewModel: NotificationsViewModel = NotificationsViewModel()) {
    val items by viewModel.items.collectAsState()
    val muted by viewModel.mutedCategories.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newBody by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Asystent") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Powiadomienia") },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF12121C))
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(imageVector = androidx.compose.material.Icons.Default.Add, contentDescription = "Dodaj powiadomienie")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = androidx.compose.foundation.layout.Alignment.CenterVertically
            ) {
                Text(text = "Wycisz kategorię:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF))
                viewModel.categories.forEach { cat ->
                    FilterChip(
                        selected = muted.contains(cat),
                        onCheckedChange = { viewModel.toggleMute(cat) },
                        label = { Text(text = cat) },
                        colors = ChipDefaults.colors(containerColor = if (muted.contains(cat)) Color(0xFF2E1B4D) else Color(0xFF1A1A28))
                    )
                }
            }
            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = items, key = { it.id }) { item ->
                    NotificationRow(item = item, muted = muted.contains(item.category), onRead = { viewModel.markRead(item.id) }, onDelete = { viewModel.delete(item.id) })
                }
            }
            if (items.isEmpty()) {
                Text(text = "Brak powiadomień", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B4B5C), modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 24.dp))
            }
        }
    }

    if (showAdd) {
        AddNotificationDialog(
            onDismiss = { showAdd = false },
            onConfirm = { title, body, category ->
                viewModel.add(title, body, category)
                showAdd = false
                newTitle = ""
                newBody = ""
            },
            title = newTitle,
            body = newBody,
            category = newCategory,
            categories = viewModel.categories,
            onTitleChange = { newTitle = it },
            onBodyChange = { newBody = it },
            onCategoryChange = { newCategory = it }
        )
    }
}

@Composable
private fun NotificationRow(
    item: NotificationItem,
    muted: Boolean,
    onRead: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161622))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text(text = item.title, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFEAEAF2))
                Chip(
                    label = { Text(text = item.category) },
                    colors = ChipDefaults.chipColors(containerColor = if (muted) Color(0xFF4B4B5C) else Color(0xFF2E1B4D)),
                    enabled = !muted
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = item.body, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9CA3AF))
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End
            ) {
                Text(text = java.time.Instant.ofEpochMilli(item.timestamp).toString().substring(0, 16), style = MaterialTheme.typography.captionSmall, color = Color(0xFF4B4B5C))
                if (!item.read) {
                    TextButton(onClick = onRead) { Text(text = "Oznacz jako przeczytane") }
                }
                IconButton(onClick = onDelete) {
                    Icon(imageVector = androidx.compose.material.Icons.Default.Delete, contentDescription = "Usuń")
                }
            }
        }
    }
}

@Composable
private fun AddNotificationDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit,
    title: String,
    body: String,
    category: String,
    categories: List<String>,
    onTitleChange: (String) -> Unit,
    onBodyChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Nowe powiadomienie") },
        text = {
            Column(modifier = Modifier.width(280.dp)) {
                TextField(value = title, onValueChange = onTitleChange, label = { Text("Tytuł") })
                Spacer(modifier = Modifier.height(8.dp))
                TextField(value = body, onValueChange = onBodyChange, label = { Text("Treść") })
                Spacer(modifier = Modifier.height(8.dp))
                DropdownMenu(
                    expanded = true,
                    onDismissRequest = {},
                    modifier = Modifier.fillMaxWidth()
                ) {
                    categories.forEach { cat ->
                        DropdownMenuItem(text = { Text(text = cat) }, onClick = { onCategoryChange(cat) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(title, body, category) }) { Text(text = "Dodaj") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(text = "Anuluj") }
        }
    )
}
